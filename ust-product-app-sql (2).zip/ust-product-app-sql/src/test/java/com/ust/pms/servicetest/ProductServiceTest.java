package com.ust.pms.servicetest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ust.pms.service.ProductService;

class ProductServiceTest {

	ProductService productService;
	
	@BeforeEach
	void setUp() throws Exception {
		productService=new ProductService();
	}

	@AfterEach
	void tearDown() throws Exception {
		productService=null;
	}

	@Test
	void testAddNumbers() {
		int expectedresult=20;
		int actualresult =productService.addNumbers(10, 10);
		
		assertEquals(expectedresult, actualresult);
	}
	
	@Test
	void testAddNumbers2() {	
		
		assertEquals(100, productService.addNumbers(50, 50));
	}

}
