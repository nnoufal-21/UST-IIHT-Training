package com.ust.pms.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.UnsupportedEncodingException;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ust.pms.model.Product;

public class ProductControllerTest extends AbstractTest {
	String uri = "/product";
	int productId = 6;

	@Override
	@Before
	public void setUp() {
		super.setUp();

	}

//	@Test
//	public void testGetProduct() throws Exception {
//
//		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
//				.andReturn();
//
//		int status = mvcResult.getResponse().getStatus();
//
//		assertEquals(200, status);
//
//		String content = mvcResult.getResponse().getContentAsString();
//
//		Product productList[] = super.mapFromJson(content, Product[].class);
//
//		assertTrue(productList.length == 12);
//
//	}

//	@Test
//	public void testGetProduct2() throws Exception {
//
//		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
//				.andReturn();
//
//		int status = mvcResult.getResponse().getStatus();
//
//		assertEquals(200, status);
//
//		String content = mvcResult.getResponse().getContentAsString();
//
//		Product productList[] = super.mapFromJson(content, Product[].class);
//
//		assertTrue(productList.length > 0);
//
//	}

	@Test
	public void testSaveProduct() throws Exception {

		Product prod = new Product(productId, "keyboard", 12, 45);
		String inputJson = super.mapToJson(prod);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();

		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content:" + content);
		assertEquals(content, "Product Added Successfully!!");
		/// this will delete this record whoch has been inserted to test
		mvc.perform(MockMvcRequestBuilders.delete(uri + "/" + productId).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
	}

	@Test
	public void testDeleteProduct() throws Exception {
		Product prod = new Product(productId, "keyboard", 12, 45);
		String inputJson = super.mapToJson(prod);
		mvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		/// this will delete this record whoch has been inserted to test
		MvcResult mvcResult = mvc
				.perform(MockMvcRequestBuilders.delete(uri + "/" + productId).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content:" + content);
		assertEquals(content, "Product Deleted SuccessFully");
	}

//	@Test
//	public void testUpdateProduct() throws Exception {
//		String uri = "/product";
//
//		Product prod = new Product(5, "piano", 63, 365);
//		String inputJson = super.mapToJson(prod);
//		MvcResult mvcResult = mvc.perform(
//				MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
//				.andReturn();
//
//		int status = mvcResult.getResponse().getStatus();
//
//		assertEquals(200, status);
//		String content = mvcResult.getResponse().getContentAsString();
//		System.out.println("content:" + content);
//		assertEquals(content, "Product Updated Successfully!!");
//	}

//
//	
//	@Test
//	void testGetProductById() {
//		fail("Not yet implemented");
//	}
//
	@Test
	public void testGetProductByName() throws Exception {
		boolean result = true;
		String productNameToSearch = "shirt";
		int count=0;
		String productSearchUri = "/product/searchProductByName/" + productNameToSearch;
		MvcResult mvcResult = mvc
				.perform(MockMvcRequestBuilders.get(productSearchUri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);

		if (status == 200) {
			String content = mvcResult.getResponse().getContentAsString();
			Product productList[] = super.mapFromJson(content, Product[].class);
			for (Product p : productList) {
				if (p.getProductName().equals(productNameToSearch)) {
					count=count+1;
					System.out.println(p);
					
				} else {
					result = false;
					break;
				}
			}
			System.out.println("Count of items with name "+productNameToSearch+":"+count);
			assertTrue(result);
		} else {
			fail("URI is not correct");
		}
		
		
	}
	@Test
	public void testsearchProductBillAmount() throws Exception{
		boolean result=true;
		int lowerRange=300;
		int greaterRange=500;
		String productSearchUri="/product/search/"+ lowerRange+"/"+greaterRange;
		MvcResult mvcResult=mvc.perform(MockMvcRequestBuilders.get(productSearchUri)
				.accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status=mvcResult.getResponse().getStatus();
		assertEquals(200, status);

		
		String content=mvcResult.getResponse().getContentAsString();
		//System.out.println(content);
		Product productList[]=super.mapFromJson(content, Product[].class);
		
		for(Product p:productList) {
			if((p.getPrice()>=lowerRange)||(p.getPrice()<=greaterRange)){
				System.out.println(p);
			}else
			{
				result=false;
				break;
			}
		}
		
		assertTrue(result);
//	}
//
//	@Test
//	void testGetProductByPriceLessThan() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetProductByPriceGreaterThan() {
//		fail("Not yet implemented");
//	}

}
}
