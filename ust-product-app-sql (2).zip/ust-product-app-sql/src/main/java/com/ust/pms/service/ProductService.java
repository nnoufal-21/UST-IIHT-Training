package com.ust.pms.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Product;
import com.ust.pms.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepository;
	
	public List<Product> displayProduct()
	{
		return (List<Product>) productRepository.findAll();
	}

	public Product displayProductById(Integer productId) {
		Optional<Product>product=productRepository.findById(productId);
		return product.get();
			}
	
	public void saveProduct(Product product)
	{
		productRepository.save(product);
	}
	
	public void deleteProduct(Integer productId) {
		productRepository.deleteById(productId);
	}
	
	public void updateProduct(Product product) {
		productRepository.save(product);
	}

	public List<Product> displayProductByName(String productName) {
		return productRepository.findByProductName(productName);
	}
	
	
	public List<Product> displayProductByPriceLessThan(int price) {
		return productRepository.findByPriceLessThan(price);
	}

	public List<Product> displayProductByPriceGreaterThan(int price) {
		return productRepository.findByPriceGreaterThan(price);
	}
	
	public boolean isProductExists(int productId)
	{
		return productRepository.findById(productId).isPresent();
		
	}
	
	public List<Product> searchProductBillAmount(int lowerRange,int greaterRange){
		return productRepository.findByPriceBetween(lowerRange, greaterRange);
	}
	
	
	public int addNumbers(int num1,int num2)
	{
		return num1+num2;
	}
}