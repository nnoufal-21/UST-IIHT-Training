package com.ust.pms.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
//@AllArgsConstructor
@NoArgsConstructor
@ToString
@AllArgsConstructor
//@Data
@ApiModel(description ="Product Model Class for this Application")
public class Product {
	@Id
	@ApiModelProperty(position = 0,required = true,notes = "Product Id is PK")
	private  int productId;
	@ApiModelProperty(position = 1,required = true,notes = "Product Name is the anme of the product")
	private  String productName;
	@ApiModelProperty(position = 2,required = true,notes = "Stock Availability")
	private  int quantityOnHand;
	@ApiModelProperty(position = 3,required = true,notes = "Price of product")
	private  int price;
}
	

	