package com.ust.pms.controller;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.pms.model.Product;
import com.ust.pms.service.ProductService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("product")
//@Slf4j
public class ProductController {
	
	Logger logger=LoggerFactory.getLogger(ProductController.class);

	@Autowired
	ProductService productService;

	@PostMapping
	public ResponseEntity<String> saveProduct(@RequestBody Product product) {
		System.out.println("Saving Product received" + product);

		if (productService.isProductExists(product.getProductId())) {
//			log.warn("############Product Already available,Not Saved!###############");
			logger.warn("############Product Already available,Not Saved!###############");
			return new ResponseEntity<String>("Product Already available,Not Saved!", HttpStatus.CONFLICT);
		} else {
			productService.saveProduct(product);
//			log.info("############Product Saved!###############");
			logger.info("############Product Saved!###############");
			return new ResponseEntity<String>("Product Added Successfully!!", HttpStatus.CREATED);

		}

	}

	@DeleteMapping("/{productId}")
	public ResponseEntity<String> deleteProduct(@PathVariable("productId") Integer productId) {
		if (productService.isProductExists(productId)) {
			productService.deleteProduct(productId);
			return new ResponseEntity<String>("Product Deleted SuccessFully", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Product Not Deleted SuccessFully", HttpStatus.NO_CONTENT);
		}
	}

	@PutMapping
	public ResponseEntity<String> updateProduct(@RequestBody Product product) {
		if (productService.isProductExists(product.getProductId())) {
			productService.updateProduct(product);
			return new ResponseEntity<String>("Product Updated Successfully!!", HttpStatus.OK);

		} else
			return new ResponseEntity<String>("Product Already available,Not Saved!", HttpStatus.CONFLICT);
	}

	@GetMapping
	@ApiOperation(value="Find All products",notes="Find the products that are saved",response=Product.class)
	public List<Product> getProduct() {
		return productService.displayProduct();
	}

	@GetMapping("/{productId}")
	
	public Product getProductById(@PathVariable("productId") Integer productId) {
		System.out.println("Get product for product Id:" + productId);
		return productService.displayProductById(productId);
	}

	@GetMapping("/searchProductByName/{productName}")
	public List<Product> getProductByName(@PathVariable("productName") String productName) {
		System.out.println("Get product for product Name:" + productName);
		return productService.displayProductByName(productName);
	}

	@GetMapping("/searchProductByPriceLessThan/{price}")
	public List<Product> getProductByPriceLessThan(@PathVariable("price") int price) {
		System.out.println("Get product for product Price Less than:" + price);
		return productService.displayProductByPriceLessThan(price);
	}

	@GetMapping("/searchProductByPriceGreaterThan/{price}")
	public List<Product> getProductByPriceGreaterThan(@PathVariable("price") int price) {
		System.out.println("Get product for product Price Greater than:" + price);
		return productService.displayProductByPriceGreaterThan(price);
	}
	
	@GetMapping(path="/search/{lowerRange}/{greaterRange}")
	public List<Product> searchProductBillAmount(@PathVariable("lowerRange") int lowerRange,
			@PathVariable("greaterRange") int greaterRange)
	 {
		System.out.println("get product for product range is "+ lowerRange + greaterRange);
		return productService.searchProductBillAmount(lowerRange,greaterRange);
	}

}
