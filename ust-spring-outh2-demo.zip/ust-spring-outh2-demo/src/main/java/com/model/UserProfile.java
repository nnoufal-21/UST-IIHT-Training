package com.model;

import lombok.Data;

@Data
public class UserProfile {
	
	
	private String name;
	private String email;
	

}
