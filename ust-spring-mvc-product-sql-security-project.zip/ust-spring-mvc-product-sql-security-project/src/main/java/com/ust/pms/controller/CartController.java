package com.ust.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;
import com.ust.pms.service.CartService;
import com.ust.pms.service.ProductService;

@RestController
public class CartController {

	@Autowired
	CartService cartService;
	@Autowired
	ProductService productService;
	
	@RequestMapping("delete/cart/{productId}")
	public ModelAndView deleteCart(@PathVariable("productId") String productId) {
		Integer pId=new Integer(productId);
		cartService.deleteProduct(pId);
	ModelAndView view=new ModelAndView();
	view.addObject("productId",productId);
	return new ModelAndView("redirect:/viewAllCartProducts");
	}
	
	
	@RequestMapping("/viewAllCartProducts")
	public ModelAndView viewAllCartProducts()
	{
		List<Cart> carts=cartService.displayProduct();
		return new ModelAndView("viewAllCartProducts","cartDetail",carts);
	}
}
