package com.ust.pms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.UserRegistration;
import javassist.expr.NewArray;

@Controller
public class IndexController {



	@RequestMapping("/")
	public ModelAndView index1() {
		String userName = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			userName = ((UserDetails) principal).getUsername();
			System.out.println("#########username:" + userName);
		}
		ModelAndView view = new ModelAndView();
		view.addObject("userName", userName);
		view.setViewName("index1");
		return view;

	}


	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model, String error, String logout) {
		if (error != null) {
			model.addAttribute("errorMsg", "username or password is incorrect");
		}
		if (logout != null) {
			model.addAttribute("msg", "succesfully logged out");
		}
		return "login";
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView register() {
		return new ModelAndView("registration", "user", new UserRegistration());
	}

	@Autowired
	JdbcUserDetailsManager jdbcUserDetailsManager;

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("user") UserRegistration userRegistration) {

		// Authorities to be granted
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
		User user = new User(userRegistration.getUsername(), userRegistration.getPassword(), authorities);
		jdbcUserDetailsManager.createUser(user);
		return new ModelAndView("login", "message","You have been successfully registered.Please login to proceed");
	}
}
