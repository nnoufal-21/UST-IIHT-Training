package com.ust.pms.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;

@Repository
public interface CartRepository extends CrudRepository<Cart, Integer> {
	
	public List<Cart> findByProductName(String productName);
	public List<Cart> findByPriceGreaterThan(int price);
	public List<Cart> findByPriceLessThan(int price);
	public List<Cart> findByPriceBetween(int lowerRange,int greaterRange);

}
