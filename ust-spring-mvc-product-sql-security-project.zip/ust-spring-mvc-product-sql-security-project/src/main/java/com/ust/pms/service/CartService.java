package com.ust.pms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;
import com.ust.pms.repository.CartRepository;

@Service
public class CartService {

	@Autowired
	CartRepository cartRepository;
	
	public List<Cart> displayProduct()
	{
		return (List<Cart>) cartRepository.findAll();
	}

	public Cart displayProductById(Integer productId) {
		Optional<Cart>product=cartRepository.findById(productId);
		return product.get();
			}
	
	public void saveProduct(Cart product)
	{
		cartRepository.save(product);
	}
	
	public void deleteProduct(Integer productId) {
		cartRepository.deleteById(productId);
	}
	
	public void updateProduct(Cart product) {
		cartRepository.save(product);
	}

	public List<Cart> displayProductByName(String productName) {
		return cartRepository.findByProductName(productName);
	}
	
	
	public List<Cart> displayProductByPriceLessThan(int price) {
		return cartRepository.findByPriceLessThan(price);
	}

	public List<Cart> displayProductByPriceGreaterThan(int price) {
		return cartRepository.findByPriceGreaterThan(price);
	}
	
	public boolean isProductExists(int productId)
	{
		return cartRepository.findById(productId).isPresent();
		
	}
}