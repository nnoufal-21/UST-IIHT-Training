package com.ust.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;
import com.ust.pms.service.CartService;
import com.ust.pms.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	CartService cartService;

	@Autowired
	ProductService productService;

	@RequestMapping("/addProduct")
	public ModelAndView addProduct() {
		return new ModelAndView("addProduct", "command", new Product());
	}

	@RequestMapping("/saveProduct")
	public String saveProduct(Product product) {
		productService.saveProduct(product);
		return "redirect:/viewAllProducts";
	}

	@RequestMapping("/cart/{productId}")
	public ModelAndView viewAllCartProduct(@PathVariable("productId") int productId) {
		Cart cart = new Cart();
		ModelAndView view = new ModelAndView();
		view.setViewName("redirect:/viewAllProducts");
		Product product = productService.displayProductById(productId);
		if (cartService.isProductExists(productId)) {
			if (product.getQuantityOnHand() > 0) {
				Cart cartProduct = cartService.displayProductById(productId);
				product.setQuantityOnHand(product.getQuantityOnHand() - 1);
				int stock = cartProduct.getQuantityOnHand() + 1;
				cart = new Cart(product.getProductId(), product.getProductName(), stock, product.getPrice());
				cartService.saveProduct(cart);
			} else
				view.addObject("command", "Out of Stock!!");
		} else {
			if (product.getQuantityOnHand() > 0) {
				product.setQuantityOnHand(product.getQuantityOnHand() - 1);
				cart = new Cart(product.getProductId(), product.getProductName(), 1, product.getPrice());
				cartService.saveProduct(cart);
			} else
				view.addObject("command", "Out of Stock!!");
		}
		return view;
	}

	@RequestMapping("/delete/{productId}")
	public ModelAndView deleteProduct(@PathVariable("productId") String productId) {
		Integer pId = new Integer(productId);
		productService.deleteProduct(pId);
		ModelAndView view = new ModelAndView();
		view.addObject("productId", productId);
		return new ModelAndView("redirect:/viewAllProducts");
	}

	@RequestMapping("/searchProductByIdForm")
	public ModelAndView searchProductByIdForm() {
		return new ModelAndView("searchProductByIdForm", "command", new Product());
	}

	@RequestMapping("/updateProduct/{productId}")
	public ModelAndView updateProductById(@PathVariable("productId") int productId) {
		Product product = productService.displayProductById(productId);

		ModelAndView view = new ModelAndView();
		view.setViewName("updateProductByIdForm");

		view.addObject("command", product);
		return view;
	}

	@RequestMapping("/updateProduct")
	public ModelAndView updateProductByIdForm(Product product) {
		productService.updateProduct(product);
		ModelAndView view = new ModelAndView();
		view.setViewName("redirect:/viewAllProducts");
		return view;
	}

	@RequestMapping("/searchProductById")
	public ModelAndView searchProductById(Product product) {
		int pid = product.getProductId();
		ModelAndView view = new ModelAndView();
		view.setViewName("searchProductByIdForm");

		if (productService.isProductExists(pid)) {
			Product desiredProduct = productService.displayProductById(pid);
			view.addObject("command", desiredProduct);
		} else {
			view.addObject("command", new Product());
			view.addObject("msg", "Product with product ID: " + pid + " does not exist!");
		}
		return view;
	}

	@RequestMapping("/deleteProductById")
	public ModelAndView deleteProductById(Product product) {
		int pid = product.getProductId();
		ModelAndView view = new ModelAndView();
		view.setViewName("searchProductByIdForm");
		view.addObject("command", new Product());
		if (productService.isProductExists(pid)) {
			productService.deleteProduct(pid);
			view.addObject("msg", "Product with product ID: " + pid + " deleted Successfully!");
		} else {

			view.addObject("msg", "Product with product ID: " + pid + " does not exist!");
		}
		return view;
	}

	@RequestMapping("/viewAllProducts")
	public ModelAndView viewAllProducts() {
		List<Product> products = productService.displayProduct();

		return new ModelAndView("viewAllProducts", "products", products);
	}

}
