package com.pms.ust.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;
import com.ust.pms.service.CartService;
import com.ust.pms.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService productService;	
	@Autowired
	CartService cartService;
	@Autowired
    private JavaMailSender mailSender;
	
	 SimpleMailMessage msg = new SimpleMailMessage();
	
	
	
	
	//List<Product> cartProducts = new ArrayList<Product>();
	@RequestMapping("/addProduct")
	public ModelAndView addProduct() {
		return new ModelAndView("addProduct", "command", new Product());
	}

	@RequestMapping("/saveProduct")
		public String saveProduct(Product product) {
		productService.saveProduct(product);
		return "success";
	}

	@RequestMapping("/searchProductByIdForm")
	public ModelAndView searchProductByIdForm() {
		return new ModelAndView("searchProductByIdForm", "command", new Product());
	}

	@RequestMapping("/searchProductById")
	public ModelAndView searchProductById(Product product) {
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("searchProductByIdForm");
		int pId = product.getProductId();
		if (productService.isProductExists(pId)) {
			Product productDetails = productService.getProduct(pId);
			modelAndView.addObject("command", productDetails);
		} else {
			modelAndView.addObject("command", new Product());
			modelAndView.addObject("msg", "Product with product id :" + pId + "does not exists");
		}
		return modelAndView;
	}

	// delete functionality in spring boot mvc
	@RequestMapping("/deleteProductById")
	public ModelAndView deleteProductById(Product product) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("searchProductByIdForm");
		modelAndView.addObject("command", new Product());
		int pId = product.getProductId();
		if (productService.isProductExists(pId)) {
			productService.deleteProduct(pId);
			modelAndView.addObject("msg", "Product with product id :" + pId + "deleted successfully");
		} else {
			modelAndView.addObject("msg", "Product with product id :" + pId + "does not exists");
		}
		return modelAndView;
	}

	// Fetch all the products
	@RequestMapping("/viewAllProducts")
	public ModelAndView viewAllProducts() {
		List<Product> products = productService.getProducts();
		return new ModelAndView("viewAllProducts", "products", products);
	}
	
	
	  // Fetch all Cart products by User	  
		@RequestMapping(value = "/{productId}")
		@ResponseBody
		public ModelAndView cart(@PathVariable("productId") int productId) {			
			ModelAndView modelAndView = new ModelAndView();			
			modelAndView.setViewName("viewAllProducts");
			// Fetching Username
			String username = null;
			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (principal instanceof UserDetails) {
				username = ((UserDetails) principal).getUsername();				
			}			
			Product productDetails = productService.getProduct(productId);		
			System.out.println("username ::::"+ username);
			
			long numberOfItemsInCartForUser = cartService.totalNumberOfProductInCart(username);	
			
			
			System.out.println("numberOfItemsInCartForUser ::::"+ numberOfItemsInCartForUser);
			if(numberOfItemsInCartForUser < 5) {
			Cart cart = new Cart(productDetails.getProductId(), productDetails.getProductName(),
					productDetails.getQuantityOnHand(), productDetails.getPrice(),
					productDetails.getQuantityOnHand() * productDetails.getPrice(), username);
			cartService.saveCart(cart);
			
//------------------------Email service
			
			
			msg.setFrom("rahulkumar2870137@gmail.com");
			msg.setTo("rahulkumar3870137@gmail.com");
			msg.setSubject("One Product hasbeen added to your Cart ");
			msg.setText("Product : " + productDetails.getProductName() + "  has been added to your Cart");
			mailSender.send(msg);
			 
			
		//------------------------------
			 
			
			
			List<Product> products = productService.getProducts();
			modelAndView.addObject(products);
			modelAndView.addObject("products", products);				
			}
			else {
				List<Product> products = productService.getProducts();
				modelAndView.addObject("products", products);
				modelAndView.addObject("msg", "Cart is full , you can Add Maximum 5 Items in Cart");					
			}			
			return modelAndView;
		}
		
	// Cart By User
	@RequestMapping("/cart")
	public ModelAndView cart() {
		String username = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		}
		List<Cart> cart = cartService.getCarts(username);
		return new ModelAndView("cart", "cart", cart);
		
	}
	
	
	  // Deleting Cart products by User	  
		@RequestMapping(value = "deleteFromCart/{productId}")
		//@ResponseBody
		public ModelAndView deleteFromCart(@PathVariable("productId") int productId) {
			System.out.println("cartProductId ::" + productId);
			Product productDetails = productService.getProduct(productId);
			cartService.deleteFromCartProduct(productId);	
			
//------------------------Email service
			
			
			msg.setFrom("rahulkumar2870137@gmail.com");
			msg.setTo("rahul.touchline@gmail.com");
			msg.setSubject("One Product hasbeen removed from your Cart ");
			msg.setText("Product : " + productDetails.getProductName() + "  has been removed from your Cart");
			mailSender.send(msg);
			 
			
		//------------------------------
			
			
				String username = null;
				Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				if (principal instanceof UserDetails) {
					username = ((UserDetails) principal).getUsername();
				}			
			List<Cart> cart = cartService.getCarts(username);
			return new ModelAndView("cart", "cart", cart);

		}
		
		
		@RequestMapping(value = "updateCart/{productId}")
		public String updateCart(@PathVariable("productId") int productId) {
			return "updateCart";

		}
		
}
