package com.ust.pms.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;

public interface CartRepository extends CrudRepository<Cart, Integer> {

	
	  public List<Cart> findByCartProductName(String cartProductName); 
	  public List<Cart> findByCartPriceGreaterThan(int price);
	  public List<Cart> findByCartUserName(String cartUserName);
	  
	  //public List<Cart> findByNumberOfItemsInCartForUser(String cartUserName);
	  
	//  public List<Cart> findBy
	 
	 

}
