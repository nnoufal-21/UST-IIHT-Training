package com.ust.pms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Cart;
import com.ust.pms.model.Product;
import com.ust.pms.repository.CartRepository;




@Service
public class CartService {
	
	@Autowired
	CartRepository cartRepository;	
	
	public void saveCart(Cart cart) {
		// This will save the product in databases
		
		cartRepository.save(cart);
	}

	
	public List<Cart> getCarts(String username) {
		return (List<Cart>) cartRepository.findByCartUserName(username);
	}

	
	public void deleteFromCartProduct(Integer cartProductId) {
		cartRepository.deleteById(cartProductId);
	}
	
	public long totalNumberOfProductInCart(String username) {		
		return cartRepository.findByCartUserName(username).size();
	}

	
	/*
	 * public Cart getCart(Integer productId) { Optional<Cart> cart =
	 * cartRepository.findById(productId); return cart.get(); }
	 */

}
