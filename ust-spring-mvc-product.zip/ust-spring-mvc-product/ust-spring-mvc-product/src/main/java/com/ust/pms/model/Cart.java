package com.ust.pms.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Entity
@Setter
@Getter
@AllArgsConstructor
@EqualsAndHashCode
@ToString
//@Component
public class Cart {

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	
	//private  @NonNull int productId;
	private  int cartProductId;
	private String cartProductName;	
	private int cartquantity;
	private int cartPrice;
	private int cartTotalPrice;	
	private String cartUserName;
	
		
	
}
